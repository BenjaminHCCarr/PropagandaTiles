int init_bg_window ( char *imagename);
void refresh_bg (float radius, float speed);
