/*
 *Most of this came from Eric Harlow's Gtk+ book, I'm only using it
 *until I port EE's fileselector code ;)
 *        -rah
 *File selection dialog
 */
#include <gtk/gtk.h>
#include "exp1.h"
static   GtkWidget     *filew;
static   char        *sFilename = NULL; 
char *rahga = "No Image Loaded";
int il = 0, ll=0 ;  
/* 
 * Get the selected filename and print it to the console 
 */
void file_ok_sel (GtkWidget *w, GtkFileSelection *fs)
{
    char *sTempFile;
    int macco;
    int sizechar;
    int machars;
    /* --- Get the name --- */
    sTempFile = gtk_file_selection_get_filename (GTK_FILE_SELECTION (fs));
    macco= (strlen (sTempFile)+1);
    sizechar = sizeof (char);
//    machars = malloc (sizechar * macco);
    /* --- Allocate space and save it. --- */
    
//    sFilename = machars;
    sFilename = (char *)malloc(sizechar * macco);
    strcpy (sFilename, sTempFile);
    il=1; ll=1;
    /* --- Destroy the file selection --- */
    gtk_widget_destroy (filew);
}


void file_cancel_sel (GtkWidget *w, GtkFileSelection *fs)
{

    /* --- Destroy the file selection --- */
    gtk_widget_destroy (filew);

}


/*
 * DestroyDialog
 *
 * Destroy the dialog (obvious, eh?) but also remove the
 * grab and close the modal. 
 */
int DestroyDialog (GtkWidget *widget, gpointer *data)
{
    gtk_grab_remove (widget);
    gtk_main_quit ();
    return (FALSE);
}


/*
 * GetFilename 
 */
char *GetFilename (char *sTitle)
{
 
    /* --- If the value is saved from last time we used the dialog,
     * --- free the memory
     */
    if (sFilename) {
        free (sFilename);
        sFilename = NULL;
    }

    /* --- Create a new file selection widget --- */
    filew = gtk_file_selection_new (sTitle);

    /* --- If it's destroyed --- */
    gtk_signal_connect (GTK_OBJECT (filew), "destroy",
            (GtkSignalFunc) DestroyDialog, &filew);

    /* --- Connect the ok_button to file_ok_sel function  --- */
    gtk_signal_connect (
            GTK_OBJECT (GTK_FILE_SELECTION (filew)->ok_button),
            "clicked", (GtkSignalFunc) file_ok_sel, filew );
    
    /* --- Connect the cancel_button to destroy the widget  --- */
    gtk_signal_connect (
             GTK_OBJECT (GTK_FILE_SELECTION (filew)->cancel_button),
             "clicked", (GtkSignalFunc) file_cancel_sel, filew);
    
    /* --- Lets set the filename, as if this were a save 
     *     dialog, and we are giving a default filename 
     */
    gtk_file_selection_set_filename (GTK_FILE_SELECTION(filew), "");
    
    /* --- Of course, we show it --- */
    gtk_widget_show (filew);

    /* --- Make sure we keep the focus --- */
    gtk_grab_add (filew);

    gtk_main ();

    return (sFilename);
}


/*
 * ButtonClicked
 *
 * Get a filename from the file selection dialog.
 */

void ButtonClicked (GtkWidget *widget, gpointer data)
{
    rahga=GetFilename ("");
    
}

char *Returnf (){
return rahga;
}



