/* Console-only interface (classic) for magicbg */
/* mental note, just compile it :) */

#include <stdlib.h>
#include <stdio.h>
#include "engine.h"
void 
display_options_to_console (char *argv[]){
  printf("  Magic Wallpaper 0.1b by Bowie J. Poag, Todd Larason,",argv[0]);
  printf("\n  Michael Jennings, and Richard Hoelscher \n",argv[0]);
  printf("  --  Usage  : %s image_file eccentricity speed\n",argv[0]);
  printf("  --  Example: %s mypicture.jpg 100 5\n",argv[0]); 
  exit(1);
}


int
main (int argc, char *argv[])
{
  int k;
  char* imagename="No image loaded.";
  int imageloaded=1;
  float radius, speed;  
  /* Process the Command Line */ 
  
  if (argc == 4) {
  imagename = argv[1];
  radius = atof(argv[2]);
  speed = atof(argv[3]);
  } else if (argc != 4){display_options_to_console(argv);}
  if (imageloaded){
      init_bg_window (imagename);
      for(k=0;1; k++){refresh_bg (radius, speed);}

  };
}





