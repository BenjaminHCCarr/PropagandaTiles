/* WARNING: PREVIEW HACK. IMPROVEMENTS WELCOME.*/
/* Included is a lot of bad style and code, used soley for */
/* the purpose of a release on July 4th with Prop 10. */
 
/* Gotta have Gtk and stdlibs... */
#include <gtk/gtk.h>  
#include <stdlib.h> /* To talk back */
#include <stdio.h>

/* And my stuff */
#include "pix.h"
#include "engine.h"
#include "fs.h"
/* Blech, Globals.... */
  gint timeOut;
  int running = 0;
  char *imagename;
  float radius,speed; 
  GtkWidget *spinner;
  GtkWidget *spinner2;

/* What do say when the user jacks it up. */
void 
display_options_to_console (char *argv[]){
  printf("  Magic Wallpaper 0.1b by Bowie J. Poag, Todd Larason,",argv[0]);
  printf("\n  Michael Jennings, and Richard Hoelscher \n",argv[0]);
  printf("  --  Usage  : %s image_file eccentricity speed\n",argv[0]);
  printf("  --  Example: %s mypicture.jpg 100 5\n",argv[0]); 
  exit(1);
}

/* Called every millisecond upon activations */
int 
runner (){
  if (running)
    {

      /*
refresh_bg(radius, speed);
*/
refresh_bg(gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(spinner)),gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(spinner2)));

}
  else
    {
      if (ll) { 
	char *test=Returnf ();
	imagename = test;
      } 
      if (il) {init_bg_window (imagename); running=1;}
    }
  return 1;
}

void 
turn_on (){
  if (il){
  timeOut =  gtk_timeout_add (1, runner, NULL);
  }
}

void 
turn_off (){
  if (running) {
    running = 0;
    gtk_timeout_remove (timeOut);
  }
}


int
main (int argc, char *argv[])
{
  int k;
  GtkWidget *filew;
  GtkWidget *window;
  GtkWidget *main_vbox;
  GtkWidget *frame;
  GtkWidget *title_label;
  GtkWidget *vbox;
  GtkWidget *vbox2;
  GtkWidget *tpix;
  GtkWidget *label;

  GtkWidget *hbox;
  GtkWidget *button;
  GtkWidget *pixmapwid;
  GdkPixmap *pixmap;
  GdkBitmap *mask;
  GtkStyle *style;
  GtkAdjustment *adj;

  /* I'll try to grab these from the command line for old-schoolers*/
 
   /* Initialize GTK */
  gtk_init (&argc, &argv);
  
  /* Process the Command Line */ 
  if (argc == 4) 
    {
    imagename = argv[1];
    radius = atof(argv[2]);
    speed = atof(argv[3]);
    il = 1;ll=0;
    } 
  else if (argc != 4 && argc != 1 )
    {display_options_to_console(argv);}
  else if (argc == 1)
    {
    imagename = "";
    radius=100;
    speed=2;
    il = 0; ll = 0;
    }

  
  /* Main Window */
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_signal_connect (GTK_OBJECT(window), 
		      "destroy",
		      GTK_SIGNAL_FUNC (gtk_main_quit),
		      NULL);
  gtk_window_set_title (GTK_WINDOW(window),
			"magicbg");
  gtk_container_set_border_width( GTK_CONTAINER (window), 2 );
  gtk_widget_show (window); 

  
  /* main_vbox */
  main_vbox = gtk_vbox_new (FALSE, 5);
  gtk_container_set_border_width (GTK_CONTAINER (main_vbox), 2);
  gtk_container_add (GTK_CONTAINER (window), main_vbox);

  /* now for the pixmap from gdk */
  style = gtk_widget_get_style( window );
  pixmap = gdk_pixmap_create_from_xpm_d( window->window,  &mask,
                                         &style->bg[GTK_STATE_NORMAL],
                                         (gchar **)xpm_title );

  /* a pixmap widget to contain the pixmap */
  pixmapwid = gtk_pixmap_new( pixmap, mask );   
  gtk_box_pack_start (GTK_BOX (main_vbox), pixmapwid, TRUE, TRUE, 0);


  /* File Selection */
  frame = gtk_frame_new ("File Selection");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE,TRUE,0);
  vbox=gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 0);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  button=gtk_button_new_with_label ("Browse..");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                             GTK_SIGNAL_FUNC (ButtonClicked),
                             NULL);
  gtk_box_pack_start (GTK_BOX (vbox), button, TRUE, TRUE, 5);

  /* Options */
  frame = gtk_frame_new ("Options");
  gtk_box_pack_start (GTK_BOX (main_vbox), frame, TRUE,TRUE,0);
  
  vbox = gtk_vbox_new (FALSE, 0);
  gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
  gtk_container_add (GTK_CONTAINER (frame), vbox);
  
  hbox = gtk_hbox_new (TRUE, 0);
  gtk_box_pack_start (GTK_BOX (vbox), hbox, TRUE,TRUE, 5);
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
         
  label = gtk_label_new ("Eccentricity:");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
         
  adj = (GtkAdjustment *) gtk_adjustment_new (radius, 0.5, 1000.0, 1.0,
                                              5.0, 0.0);
  spinner = gtk_spin_button_new (adj, 0, 0);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner), TRUE);
  gtk_spin_button_set_shadow_type (GTK_SPIN_BUTTON (spinner),
                                   GTK_SHADOW_OUT);
  
  gtk_box_pack_start (GTK_BOX (vbox2), spinner, FALSE, TRUE, 0);
         
  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (hbox), vbox2, TRUE, TRUE, 5);
         
  label = gtk_label_new ("Speed :    ");
  gtk_misc_set_alignment (GTK_MISC (label), 0, 0.5);
  gtk_box_pack_start (GTK_BOX (vbox2), label, FALSE, TRUE, 0);
         
  adj = (GtkAdjustment *) gtk_adjustment_new (speed, 0.2, 200.0, .1,
                                              1.0, 0.0);
  spinner2 = gtk_spin_button_new (adj, 0, 1);
  gtk_spin_button_set_wrap (GTK_SPIN_BUTTON (spinner2), TRUE);
  gtk_spin_button_set_shadow_type (GTK_SPIN_BUTTON (spinner2),
                                          GTK_SHADOW_ETCHED_IN);
  gtk_box_pack_start (GTK_BOX (vbox2), spinner2, FALSE, TRUE, 0);
  




  /*-- Bottom  --*/
  hbox = gtk_hbox_new (FALSE, 0);
  gtk_box_pack_start (GTK_BOX (main_vbox), hbox, FALSE, TRUE, 0);

  /* Start */
  button = gtk_button_new_with_label ("Start");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (turn_on),
                               NULL);
  gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 5);

  /* Stop */
  button = gtk_button_new_with_label ("Stop");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (turn_off),
                               NULL);
  gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 5);
  
  /* Exit */
  button = gtk_button_new_with_label ("Exit");
  gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (gtk_widget_destroy),
                               GTK_OBJECT (window));
  gtk_box_pack_start (GTK_BOX (hbox), button, TRUE, TRUE, 5);

  


  /* All good, leftover crud */
  gtk_widget_show_all (window);

  gtk_main ();

  return (0);

}
