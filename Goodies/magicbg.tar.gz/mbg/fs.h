void ButtonClicked (GtkWidget *widget, gpointer data);
char *Returnf();
int il, ll; 
